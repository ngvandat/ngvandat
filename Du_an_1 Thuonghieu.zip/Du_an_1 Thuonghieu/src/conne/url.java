package conne;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.sql.*;

/**
 *
 * @author dat07
 */
public class url {
    protected Connection con;
    protected Statement stm;
    protected PreparedStatement pstm;
    protected  ResultSet rs;
    public url(){
        String url = "jdbc:sqlserver://localhost:1433;databaseName=Du_An_1;user=sa;password=dat12345;encrypt=false";
        try {
            con= DriverManager.getConnection(url);
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
    }
}
