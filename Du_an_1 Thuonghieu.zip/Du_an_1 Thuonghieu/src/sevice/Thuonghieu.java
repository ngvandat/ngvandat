/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sevice;

/**
 *
 * @author dat07
 */
public class Thuonghieu {

    Integer id;
    String tenth;

    public Thuonghieu() {
    }

    public Thuonghieu(Integer id, String tenth) {
        this.id = id;
        this.tenth = tenth;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTenth() {
        return tenth;
    }

    public void setTenth(String tenth) {
        this.tenth = tenth;
    }

}
